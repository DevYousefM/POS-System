<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.createUserTitle'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.editUserTitle'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dash.products.index')); ?>"><?php echo app('translator')->get('site.products'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.editUserTitle'); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">

                <!-- general form elements -->
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.editUserTitle'); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <?php echo $__env->make("components.dashboard.includes.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form role="form" action="<?php echo e(route("dash.products.update",$product)); ?>" enctype="multipart/form-data"
                          method="post">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body pb-0">
                            <div class="form-group uploadImage">
                                <label for="imageField"><?php echo app('translator')->get("site.ProImage"); ?></label>
                                <div class="input-group">
                                    <div>
                                        <img id="imagePlace" src="<?php echo e(asset("uploads/".$product->image)); ?>"
                                             style="height:  38px"
                                             class="img-thumbnail"/>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" accept="image/*" name="image" class="custom-file-input"
                                               id="imageField">
                                        <label class="custom-file-label"
                                               for="imageField"><?php echo app('translator')->get("site.chooseFile"); ?></label>
                                    </div>
                                    <div class="input-group-append">
                                        <span class="input-group-text" id=""><?php echo app('translator')->get("site.upload"); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex flex-row justify-content-between flex-wrap">
                                <div class="form-group col-md-4 col-sm-5 p-0">
                                    <label for="purchase_price"><?php echo app('translator')->get("site.purchase_price"); ?></label>
                                    <input type="number" class="form-control" value="<?php echo e($product->purchase_price); ?>"
                                           id="purchase_price"
                                           placeholder="<?php echo app('translator')->get("site.purchase_price"); ?>" name="purchase_price"
                                    >
                                </div>
                                <div class="form-group col-md-4 px-md-3 col-sm-5 px-0">
                                    <label for="sell_price"><?php echo app('translator')->get("site.sell_price"); ?></label>
                                    <input type="number" class="form-control" value="<?php echo e($product->sell_price); ?>"
                                           id="sell_price"
                                           placeholder="<?php echo app('translator')->get("site.sell_price"); ?>" name="sell_price"
                                    >
                                </div>
                                <div class="form-group col-md-4 col-12 p-0">
                                    <label for="stock"><?php echo app('translator')->get("site.stock"); ?></label>
                                    <input type="number" class="form-control" value="<?php echo e($product->stock); ?>" id="stock"
                                           placeholder="<?php echo app('translator')->get("site.stock"); ?>" name="stock"
                                    >
                                </div>
                            </div>
                            <div class="form-group ">
                                <label><?php echo app('translator')->get("site.category"); ?></label>
                                <select class="custom-select" name="category">
                                    <?php if(count($categories) > 0): ?>
                                        <option><?php echo app('translator')->get("site.select_cat"); ?></option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($category->id); ?>" <?php echo e($product->category_id === $category->id ? "selected" : null); ?> ><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__currentLoopData = $product->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <label for="exampleInputFName"><?php echo app('translator')->get("site.".$trans->locale.".name"); ?></label>
                                    <input type="text" class="form-control" id="exampleInputFName"
                                           name="<?php echo e($trans->locale); ?>[name]"
                                           placeholder="<?php echo app('translator')->get("site.ProName"); ?>"
                                           value="<?php echo e($trans->name); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $product->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <label><?php echo app('translator')->get("site.".$trans->locale.".desc"); ?></label>
                                    <textarea class="form-control ckeditor" name="<?php echo e($trans->locale); ?>[desc]" rows="2"
                                              placeholder="<?php echo app('translator')->get("site.ProDesc"); ?>"><?php echo e($trans->desc); ?></textarea>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- /.col -->
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get("site.edit"); ?><i class="fa fa-edit"></i>
                    </button>
                </div>
                </form>
            </div>
            <!-- /.card -->
    </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- ckeditor5 -->
    <script src="<?php echo e(asset('dashboard/plugins/ckeditor5/ckeditor.js')); ?>"></script>
    <?php if(App::getLocale() !== "en"): ?>
        <script src="<?php echo e(asset('dashboard/plugins/ckeditor5/translations/'.App::getlocale().'.js')); ?>"></script>
    <?php endif; ?>
    <script>
        imageField.onchange = evt => {
            const [file] = imageField.files
            if (file) {
                imagePlace.src = URL.createObjectURL(file)
            }
        }

        document.querySelectorAll(".ckeditor").forEach((x) => {
            ClassicEditor
                .create(x, {
                    language: "<?php echo e(App::getLocale()); ?>"
                })
                .then(editor => {
                    console.log(editor);
                })
                .catch(error => {
                    console.error(error);
                });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\POS-New\resources\views/dashboard/products/edit.blade.php ENDPATH**/ ?>