<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.orders'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.orders'); ?> (<?php echo e($orders->total()); ?>)
                            <?php echo e(isset($dailyInvoice) ? "| " . __("site.dailyInvoice") : null); ?>

                            <?php echo e(isset($yearlyInvoice) ? "| " . __("site.yearlyOrders") : null); ?>

                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.orders'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>

        </section>
        <div class="container">
            <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php
            $read = auth()->user()->hasPermission("orders_read");
            $edit = auth()->user()->hasPermission("orders_update");
            $delete = auth()->user()->hasPermission("orders_delete");
            $create = auth()->user()->hasPermission("orders_create");
        ?>
        <section class="content-header">
            <div class="container-fluid">
                <form class="row flex-row-reverse" action="<?php echo e(route('dash.orders.index')); ?>" method="get">
                    <div class="col-md-4 col-6">
                        <input type="text" name="search" value="<?php echo e(request()->search); ?>"
                               placeholder="<?php echo app('translator')->get("site.searchAboutOr"); ?>" class="form-control">
                    </div>
                    <div class="d-flex">

                        <button type="submit" class="btn btn-info mx-1"
                        ><?php echo app('translator')->get("site.search"); ?> <i
                                class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>
        </section>
        <div class="content">
            <div class="container-fluid">
                <div class="ordersPage">
                    <div class="card card-info card-outline p-1" id="ordersT">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.orders'); ?></h3>
                        </div>

                        <table id="ordersTable"

                               style="font-size: 15px;width: 100%;text-align: center;padding-right: 10px;padding-left: 10px;"
                        >
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo app('translator')->get('site.clientName'); ?></th>
                                <th><?php echo app('translator')->get('site.price'); ?></th>
                                <th><?php echo app('translator')->get('site.discount'); ?></th>
                                <th><?php echo app('translator')->get('site.created_at'); ?></th>
                                <th><?php echo app('translator')->get('site.action'); ?></th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $count = 1; ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?= $count ?></td>
                                    <td style="text-transform: capitalize">
                                        <?php echo e($order->client->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format($order->total_price,2)); ?>

                                    </td>
                                    <td>
                                        <?php echo e($order->discount != null ?$order->discount : 0); ?>

                                    </td>
                                    <td>
                                        <?php echo e($order->created_at->toFormattedDateString()); ?>

                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <button
                                                data-url="<?php echo e(route("dash.orders.products",$order->id)); ?>"
                                                data-method="get"
                                                class="btn btn-info mr-1  show-products-btn <?php echo e($read ? "" : 'disabled'); ?>"
                                            >
                                                
                                                <i class="fa fa-eye"></i>
                                            </button>
                                            <a href="<?php echo e($edit ? route("dash.clients.orders.edit",["client"=>$order->client->id,"order"=> $order]) : "#"); ?>"
                                               class="btn btn-info mr-1 <?php echo e($edit ? "" : 'disabled'); ?>">
                                                
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form class="formDelete"
                                                  onsubmit="return confirm('<?php echo app('translator')->get("site.delete_confirm_order"); ?>');"
                                                  action="<?php echo e($delete ? route("dash.orders.destroy",$order) : "#"); ?>"
                                                  method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                        class="btn btn-danger <?php echo e($delete ? "" : 'disabled'); ?>"
                                                        style="<?php echo e($delete ? "" : "cursor: not-allowed"); ?>"
                                                >
                                                    
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                    <?php $count++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">

                            <?php echo e($orders->appends(request()->query())->links()); ?>

                        </div>
                    </div>
                    <div class="card card-info card-outline p-1" id="ordersT">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.show'); ?> <?php echo app('translator')->get('site.products'); ?></h3>
                        </div>
                        <div class="box-body">
                            <div id="order-product-list">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('script'); ?>
            <!-- jQuery -->
            <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
            <!-- Bootstrap 4 rtl -->
            <script src="https://cdn.rtlcss.com/bootstrap/v4.2.1/js/bootstrap.min.js"></script>
            <!-- Bootstrap 4 -->
            <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
            <!-- DataTables -->
            <script src="<?php echo e(asset('dashboard/plugins/datatables/jquery.dataTables.js')); ?>"></script>
            <script src="<?php echo e(asset('dashboard/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
            <!-- Order Js Code -->
            <script src="<?php echo e(asset('dashboard/dist/js/order.js')); ?>"></script>
            <!-- jQuery Print Plugin -->

            <script src="<?php echo e(asset('dashboard/plugins/jquery-print/jquery.print.js')); ?>"></script>
            <script>
                $(function () {
                    $('#ordersTable').DataTable({
                        "paging": false,
                        "searching": false,
                        "info": false,
                        "ordering": true,
                        "language": {
                            "infoEmpty": "<?php echo app('translator')->get('site.emptyTable'); ?>",
                            "zeroRecords": "<?php echo app('translator')->get('site.emptyTable'); ?>",
                        }
                    });
                });
            </script>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>