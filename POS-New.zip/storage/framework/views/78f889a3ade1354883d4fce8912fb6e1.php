<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.createCategoryTitle'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.editCategoryTitle'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dash.categories.index')); ?>"><?php echo app('translator')->get('site.categories'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.editCategoryTitle'); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">

                <!-- general form elements -->
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.editCategoryTitle'); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <?php echo $__env->make("components.dashboard.includes.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form role="form" action="<?php echo e(route("dash.categories.update",$category)); ?>"
                          enctype="multipart/form-data"
                          method="post">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body pb-0">
                            <?php $__currentLoopData = $category->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <label for="exampleInputFName"><?php echo app('translator')->get("site." . $trans->locale .  ".name"); ?></label>
                                    <input type="text" class="form-control" id="exampleInputFName"
                                           name="<?php echo e($trans->locale); ?>[name]"
                                           value="<?php echo e($trans->name); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-footer pr-0" style="background-color: transparent">
                                <button type="submit" class="btn btn-primary"><?php echo app('translator')->get("site.edit"); ?> <i
                                        class="fa fa-edit"></i>
                                </button>
                            </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script>
        imageField.onchange = evt => {
            const [file] = imageField.files
            if (file) {
                imagePlace.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/categories/edit.blade.php ENDPATH**/ ?>