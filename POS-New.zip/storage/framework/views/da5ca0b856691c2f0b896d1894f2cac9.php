<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route("dash.index")); ?>" class="nav-link"><?php echo app('translator')->get("site.home"); ?></a>
        </li>
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav mr-auto-navbav">
        <!-- Messages Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="fas fa-language"></i>
            </a>
            <div class="dropdown-menu lang dropdown-menu-lg dropdown-menu-right">
                <?php $devider = 1; ?>
                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a rel="alternate" hreflang="<?php echo e($localeCode); ?>" class="dropdown-item"
                       href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                        <?php echo e($properties['native']); ?>

                    </a>
                    <?php if($devider % 2): ?>
                        <div class="dropdown-divider"></div>
                    <?php endif; ?>
                        <?php $devider++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
        <li class="nav-item">
            <form action="<?php echo e(route("logout")); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="<?php echo e(route("logout")); ?>"
                   onclick="event.preventDefault();this.closest('form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </form>
        </li>

    </ul>
</nav>

<!-- /.navbar -->
<?php /**PATH E:\POS-New\resources\views/components/dashboard/_navbar.blade.php ENDPATH**/ ?>