<?php if(session('message')): ?>
    <div id="result" class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
<script>
    let result = document.getElementById("result");
    if (result) {
        setTimeout(() => {
            result.remove();
        }, 5000);
    }
</script>
<?php /**PATH F:\POS-New\resources\views/components/dashboard/includes/message.blade.php ENDPATH**/ ?>