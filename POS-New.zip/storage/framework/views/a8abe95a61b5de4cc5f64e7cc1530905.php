<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.trash'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.trash'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.trash'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-12">
                    <div class="card card-info card-outline p-1" style="height: fit-content;">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.recycles'); ?></h3>
                        </div>
                        
                        <?php if(count($categories) > 0): ?>
                            <div class="accordion mt-3" id="categories">
                                <div class="card">
                                    <div class="card-header p-0" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-info btn-block text-left" type="button"
                                                    data-toggle="collapse" data-target="#collapseCategory"
                                                    aria-expanded="true"
                                                    aria-controls="collapseOne">
                                                <?php echo app('translator')->get("site.categories"); ?>
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseCategory" class="collapse"
                                         aria-labelledby="headingOne"
                                         data-parent="#categories">
                                            <?php $count = 0 ?>
                                        <table class="table table-striped">
                                            <tbody>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $count++ ?>
                                                <tr>
                                                    <td><?php echo e($count); ?>.</td>
                                                    <td><?php echo e($category->name); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.restore",["table"=>"categories","id"=>$category->id])); ?>"
                                                           class="btn btn-info mr-1">
                                                            <?php echo app('translator')->get("site.restore"); ?>
                                                            <i class="fa fa-undo"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.forceDelete",["table"=>"categories","id"=>$category->id])); ?>"
                                                           class="btn btn-danger mr-1">
                                                            <?php echo app('translator')->get("site.deletePer"); ?>
                                                            <i class="fa fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if( isset($products) && count($products) > 0): ?>
                            <div class="accordion mt-3" id="products">
                                <div class="card">
                                    <div class="card-header p-0" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-info btn-block text-left" type="button"
                                                    data-toggle="collapse" data-target="#collapseProduct"
                                                    aria-expanded="true"
                                                    aria-controls="collapseOne">
                                                <?php echo app('translator')->get("site.products"); ?>
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseProduct" class="collapse"
                                         aria-labelledby="headingOne"
                                         data-parent="#products">
                                            <?php $count = 0 ?>
                                        <table class="table table-striped">
                                            <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $count++ ?>
                                                <tr>
                                                    <td><?php echo e($count); ?>.</td>
                                                    <td><?php echo e($product->name); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.restore",["table"=>"products","id"=>$product->id])); ?>"
                                                           class="btn btn-info mr-1">
                                                            <?php echo app('translator')->get("site.restore"); ?>
                                                            <i class="fa fa-undo"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.forceDelete",["table"=>"products","id"=>$category->id])); ?>"
                                                           class="btn btn-danger mr-1">
                                                            <?php echo app('translator')->get("site.deletePer"); ?>
                                                            <i class="fa fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($clients) && count($clients) > 0): ?>
                            <div class="accordion mt-3" id="clients">
                                <div class="card">
                                    <div class="card-header p-0" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-info btn-block text-left" type="button"
                                                    data-toggle="collapse" data-target="#collapseClient"
                                                    aria-expanded="true"
                                                    aria-controls="collapseOne">
                                                <?php echo app('translator')->get("site.clients"); ?>
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseClient" class="collapse"
                                         aria-labelledby="headingOne"
                                         data-parent="#clients">
                                            <?php $count = 0 ?>
                                        <table class="table table-striped">
                                            <tbody>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $count++ ?>
                                                <tr>
                                                    <td><?php echo e($count); ?>.</td>
                                                    <td><?php echo e($client->name); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.restore",["table"=>"clients","id"=>$client->id])); ?>"
                                                           class="btn btn-info mr-1">
                                                            <?php echo app('translator')->get("site.restore"); ?>
                                                            <i class="fa fa-undo"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route("dash.trash.forceDelete",["table"=>"clients","id"=>$client->id])); ?>"
                                                           class="btn btn-danger mr-1">
                                                            <?php echo app('translator')->get("site.deletePer"); ?>
                                                            <i class="fa fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<style>
    .uploadImage .custom-file-label::after {
        content: "<?php echo app('translator')->get("site.browse"); ?>"
    }
</style>
<?php $__env->startSection('script'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Order Js Code -->
    <script src="<?php echo e(asset('dashboard/dist/js/order.js')); ?>"></script>
    <!-- Number Jquery Plugin -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery-number/jquery.number.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/trash/index.blade.php ENDPATH**/ ?>