<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.expenses'); ?> <?php echo e(isset($dailyExpenses) ? "| " . __("site.dailyExpenses") : null); ?><?php echo e(isset($monthlyExpenses) ? "| " . __("site.monthlyExpenses") : null); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.expenses'); ?>
                            <?php echo e(isset($dailyExpenses) ? "| " . __("site.dailyExpenses") : null); ?>

                            <?php echo e(isset($monthlyExpenses) ? "| " . __("site.monthlyExpenses") : null); ?>



                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.expenses'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>

        </section>
        <div class="container">
            <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("components.dashboard.includes.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <section class="content-header">
            <div class="container-fluid">
                <form class="row flex-row-reverse" action="<?php echo e(route('dash.expenses.index')); ?>" method="get">
                    <div class="col-md-4 col-6">
                        <input type="text" name="search" value="<?php echo e(request()->search); ?>"
                               class="form-control">
                    </div>
                    <div class="d-flex">

                        <button type="submit" class="btn btn-info mx-1"
                        ><?php echo app('translator')->get("site.search"); ?> <i
                                class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>
        </section>
        <div class="content">
            <div class="container-fluid">
                <div class="ordersPage" style="flex-direction: row-reverse">
                    <div class="card card-info card-outline p-1" id="expensesT">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.expenses'); ?></h3>
                        </div>

                        <table id="expensesTable"
                               class="table table-bordered"
                               style="font-size: 15px;width: 100%;text-align: center;padding-right: 10px;padding-left: 10px;"
                        >
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('site.reason'); ?></th>
                                <th><?php echo app('translator')->get('site.value'); ?></th>
                                <th><?php echo app('translator')->get('site.theDate'); ?></th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-transform: capitalize">
                                        <?php echo e($expense->reason); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format($expense->value,2)); ?>

                                    </td>
                                    <td>
                                        <?php echo e($expense->created_at->toFormattedDateString()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">

                            <?php echo e($expenses->appends(request()->query())->links()); ?>

                        </div>
                    </div>
                    <div class="card card-info card-outline p-1" id="expensesT">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.add'); ?></h3>
                        </div>
                        <div class="box-body ">
                            <form role="form" action="<?php echo e(route("dash.expenses.store")); ?>"
                                  method="post">
                                <?php echo method_field("post"); ?>
                                <?php echo csrf_field(); ?>
                                <div class="card-body pb-0">
                                    <div class="form-group">
                                        <label for="exampleInputFName"><?php echo app('translator')->get("site.value"); ?></label>
                                        <input type="number" class="form-control" id="exampleInputFName"
                                               name="value"
                                               value="<?php echo e(old("value")); ?>">
                                    </div>
                                    <?php $__currentLoopData = config("translatable.locales"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group">
                                            <label for="exampleInputFName"><?php echo app('translator')->get("site.".$locale.".reason"); ?></label>
                                            <input type="text" class="form-control" id="exampleInputFName"
                                                   name="<?php echo e($locale); ?>[reason]"
                                                   value="<?php echo e(old($locale.".reason")); ?>">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get("site.add"); ?> <i
                                            class="fa fa-plus"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('script'); ?>
            <!-- jQuery -->
            <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
            <!-- Bootstrap 4 rtl -->
            <script src="https://cdn.rtlcss.com/bootstrap/v4.2.1/js/bootstrap.min.js"></script>
            <!-- Bootstrap 4 -->
            <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
            <!-- DataTables -->
            <script src="<?php echo e(asset('dashboard/plugins/datatables/jquery.dataTables.js')); ?>"></script>
            <script src="<?php echo e(asset('dashboard/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
            <!-- Order Js Code -->
            <script src="<?php echo e(asset('$dashboard/dist/js/expense.js')); ?>"></script>
            <!-- jQuery Print Plugin -->

            <script src="<?php echo e(asset('dashboard/plugins/jquery-print/jquery.print.js')); ?>"></script>
            <script>
                $(function () {
                    $('#expensesTable').DataTable({
                        "paging": false,
                        "searching": false,
                        "info": false,
                        "ordering": true,
                        "language": {
                            "infoEmpty": "<?php echo app('translator')->get('site.emptyTable'); ?>",
                            "zeroRecords": "<?php echo app('translator')->get('site.emptyTable'); ?>",
                        }
                    });
                });
            </script>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/expenses/index.blade.php ENDPATH**/ ?>