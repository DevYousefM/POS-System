<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.categories'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.categories'); ?> (<?php echo e($categories->total()); ?>)</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.categories'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>

        </section>
        <div class="container">
            <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php
            $edit = auth()->user()->hasPermission("categories_update");
            $delete = auth()->user()->hasPermission("categories_delete");
        ?>
        <section class="content-header">
            <div class="container-fluid">
                <form class="row flex-row-reverse" action="<?php echo e(route('dash.categories.index')); ?>" method="get">
                    <div class="col-md-4 col-6">
                        <input type="text" name="search" value="<?php echo e(request()->search); ?>"
                               placeholder="<?php echo app('translator')->get("site.searchAboutCa"); ?>" class="form-control">
                    </div>
                    <div class="d-flex">
                        <?php if(auth()->user()->hasPermission("categories_create")): ?>
                            <a class="btn btn-info" href="<?php echo e(route("dash.categories.create")); ?>"><?php echo app('translator')->get("site.add"); ?> <i
                                    class="fa fa-plus"></i> </a>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-info mx-1"
                        ><?php echo app('translator')->get("site.search"); ?> <i
                                class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>
        </section>
        <div class="content">
            <div class="container-fluid" id="categoriesT">
                <table id="categoriesTable" class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('site.name'); ?></th>
                        <th><?php echo app('translator')->get('site.products_number'); ?></th>
                        <th><?php echo app('translator')->get('site.related_products'); ?></th>
                        <th><?php echo app('translator')->get('site.action'); ?></th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $count = 1; ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?= $count ?></td>
                            <td>
                                <?php echo e($category->name); ?>

                            </td>
                            <td>
                                <?php echo e($category->products->count()); ?>

                            </td>
                            <td>
                                <a class="btn btn-info "
                                   href="<?php echo e(route("dash.products.index",["category"=>$category->id])); ?>"><?php echo app('translator')->get("site.related_products"); ?></a>

                            </td>
                            <td>
                                <div class="d-flex">


                                    <a href="<?php echo e($edit ? route("dash.categories.edit",$category) : "#"); ?>"
                                       class="btn btn-info mr-1 <?php echo e($edit ? "" : 'disabled'); ?>">
                                        
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <form class="formDelete"
                                          onsubmit="return confirm('<?php echo app('translator')->get("site.delete_confirm_category"); ?>');"
                                          action="<?php echo e($delete ? route("dash.categories.destroy",$category) : "#"); ?>"
                                          method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="btn btn-danger <?php echo e($delete ? "" : 'disabled'); ?>"
                                                style="<?php echo e($delete ? "" : "cursor: not-allowed"); ?>"
                                        >
                                            
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                            <?php $count++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-center">

                    <?php echo e($categories->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('script'); ?>
            <!-- jQuery -->
            <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
            <!-- Bootstrap 4 rtl -->
            <script src="https://cdn.rtlcss.com/bootstrap/v4.2.1/js/bootstrap.min.js"></script>
            <!-- Bootstrap 4 -->
            <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
            <!-- DataTables -->
            <script src="<?php echo e(asset('dashboard/plugins/datatables/jquery.dataTables.js')); ?>"></script>
            <script src="<?php echo e(asset('dashboard/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
            <script>
                $(function () {
                    $('#categoriesTable').DataTable({
                        "paging": false,
                        "scrollY": '50vh',
                        "scrollCollapse": true,
                        "scrollX": true,
                        "lengthChange": true,
                        "searching": false,
                        "ordering": true,
                        "info": false,
                        "autoWidth": false,
                        "language": {
                            "lengthMenu": " _MENU_ ",
                            "zeroRecords": "Empty",
                            "info": "<?php echo app('translator')->get('site.infoS'); ?> (_PAGE_) <?php echo app('translator')->get('site.page'); ?> <?php echo app('translator')->get('site.of'); ?> (_PAGES_) <?php echo app('translator')->get('site.pages'); ?>",
                            "infoEmpty": "<?php echo app('translator')->get('site.emptyTable'); ?>",
                            "search": "<?php echo app('translator')->get('site.search'); ?> : ",
                        }
                    });
                });
            </script>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\POS-New\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>