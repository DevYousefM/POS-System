<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.createCategoryTitle'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.createCategoryTitle'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dash.categories.index')); ?>"><?php echo app('translator')->get('site.categories'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.titleCategoryCreate'); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">

                <!-- general form elements -->
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.titleCategoryCreate'); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <?php echo $__env->make("components.dashboard.includes.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form role="form" action="<?php echo e(route("dash.categories.store")); ?>"
                          method="post">
                        <?php echo method_field("post"); ?>
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = config("translatable.locales"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body pb-0">
                                <div class="form-group">
                                    <label for="exampleInputFName"><?php echo app('translator')->get("site.".$locale.".name"); ?></label>
                                    <input type="text" class="form-control" id="exampleInputFName"
                                           name="<?php echo e($locale); ?>[name]"
                                           value="<?php echo e(old($locale.".name")); ?>">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get("site.add"); ?> <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<style>
    .uploadImage .custom-file-label::after {
        content: "<?php echo app('translator')->get("site.browse"); ?>"
    }
</style>
<?php $__env->startSection('script'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/categories/create.blade.php ENDPATH**/ ?>