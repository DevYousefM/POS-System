<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get('site.createOrderTitle'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo app('translator')->get('site.createOrderTitle'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dash.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dash.clients.index')); ?>"><?php echo app('translator')->get('site.clients'); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.titleOrderCreate'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <?php echo $__env->make("components.dashboard.includes.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="orderCreate">

                    <div class="card card-info card-outline p-1" style="height: fit-content;">
                        <div class="card-header">
                            <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.categories'); ?></h3>
                        </div>

                        <div class="accordion mt-3" id="categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->products->count() > 0): ?>
                                    <div class="card">
                                        <div class="card-header p-0" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-info btn-block text-left" type="button"
                                                        data-toggle="collapse" data-target="#collapse<?php echo e($category->id); ?>"
                                                        aria-expanded="true"
                                                        aria-controls="collapseOne">
                                                    <?php echo e($category->name); ?>

                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapse<?php echo e($category->id); ?>" class="collapse"
                                             aria-labelledby="headingOne"
                                             data-parent="#categories">

                                            <table class="table table-striped">
                                                <thead>
                                                <tr>
                                                    <th><?php echo app('translator')->get("site.name"); ?></th>
                                                    <th><?php echo app('translator')->get("site.stock"); ?></th>
                                                    <th><?php echo app('translator')->get("site.price"); ?></th>
                                                    <th><?php echo app('translator')->get("site.add"); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($product->name); ?></td>
                                                        <td>
                                                            <?php echo e($product->stock); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($product->sell_price); ?>

                                                        </td>
                                                        <td>
                                                            <button
                                                                class="btn btn-success add-product-btn"
                                                                id="product-<?php echo e($product->id); ?>"
                                                                data-name="<?php echo e($product->name); ?>"
                                                                data-price="<?php echo e($product->sell_price); ?>"
                                                                data-id="<?php echo e($product->id); ?>"
                                                            ><i
                                                                    class="fas fa-plus"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <div>
                        <div class="card card-info card-outline p-1">
                            <?php echo $__env->make("components.dashboard.includes.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form method="POST" action="<?php echo e(route("dash.clients.orders.store",$client->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("POST"); ?>
                                <div class="card-header">
                                    <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.orders'); ?></h3>
                                </div>

                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th><?php echo app('translator')->get("site.product"); ?></th>
                                        <th><?php echo app('translator')->get("site.quantity"); ?></th>
                                        <th><?php echo app('translator')->get("site.price"); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody class="order-list">

                                    </tbody>
                                </table>
                                <div class="d-flex flex-wrap justify-content-around">
                                    <label style="font-size: 20px;font-weight: 400;"
                                           class="d-flex"><?php echo app('translator')->get("site.discount"); ?> :
                                        <span>
                                        <input type="number" name="discount" id="discount" min="0" value="0"
                                               class="form-control text-center" style="width: 60px">
                                        </span>
                                    </label>
                                    <label style="font-size: 20px;font-weight: 400"><?php echo app('translator')->get("site.total"); ?> : <span
                                            id="total">0</span></label>
                                </div>
                                <button class="btn btn-info btn-block disabled" id="add-order"
                                        style="cursor: not-allowed"><?php echo app('translator')->get("site.add"); ?> <i
                                        class="fas fa-plus"></i></button>
                            </form>
                        </div>
                        <?php if($client->orders()->count() > 0): ?>
                            <div class="card card-info card-outline p-1">


                                <div class="card-header">
                                    <h3 class="card-title float-none mb-0"><?php echo app('translator')->get('site.previous_orders'); ?> <?php echo e($client->orders()->count()); ?> </h3>
                                </div>


                                <div class="accordion mt-3" id="categories">
                                    <?php $__currentLoopData = $client->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card">
                                            <div class="card-header p-0" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-info btn-block text-left" type="button"
                                                            data-toggle="collapse"
                                                            data-target="#collapseOrder<?php echo e($order->id); ?>"
                                                            aria-expanded="true"
                                                            aria-controls="collapseOne">
                                                        <?php echo e($order->created_at->format("d-m-Y")); ?>

                                                    </button>
                                                </h2>
                                            </div>
                                            <div id="collapseOrder<?php echo e($order->id); ?>" class="collapse"
                                                 aria-labelledby="headingOne"
                                                 data-parent="#categories">

                                                <table class="table table-striped table-borderless mb-0"
                                                       style="font-size: 15px">
                                                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <thead>
                                                        <tr>
                                                            <th><?php echo app('translator')->get("site.product"); ?></th>
                                                            <th><?php echo app('translator')->get("site.quantity"); ?></th>
                                                            <th><?php echo app('translator')->get("site.product_price"); ?></th>
                                                        </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tr>
                                                            <td><?php echo e($product->name); ?></td>
                                                            <td>
                                                                <?php echo e($product->pivot->quantity); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($product->sell_price); ?>

                                                            </td>
                                                        </tr>
                                                        </tbody>
                                                        <thead>


                                                        <tr>
                                                            <th>
                                                                <?php echo app('translator')->get("site.total"); ?> :

                                                            </th>
                                                            <th>
                                                                <?php echo e($product->sell_price * $product->pivot->quantity); ?>

                                                            </th>
                                                        </tr>
                                                        </thead>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </table>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </div>
                        <?php endif; ?>

                    </div>


                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<style>
    .uploadImage .custom-file-label::after {
        content: "<?php echo app('translator')->get("site.browse"); ?>"
    }
</style>
<?php $__env->startSection('script'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Order Js Code -->
    <script src="<?php echo e(asset('dashboard/dist/js/order.js')); ?>"></script>
    <!-- Number Jquery Plugin -->
    <script src="<?php echo e(asset('dashboard/plugins/jquery-number/jquery.number.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\POS-New\resources\views/dashboard/clients/orders/create.blade.php ENDPATH**/ ?>