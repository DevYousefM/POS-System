<div class="card mt-1 p-1 pt-0">
    <div class="print-area">
        <table class="table table-bordered orderProductTable">
            <thead>
            <tr>
                <th><?php echo app('translator')->get("site.name"); ?></th>
                <th><?php echo app('translator')->get("site.quantity"); ?></th>
                <th><?php echo app('translator')->get("site.price"); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->pivot->quantity); ?></td>
                    <td><?php echo e(number_format($product->pivot->quantity * $product->sell_price , 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex flex-wrap justify-content-between">
            <h5><?php echo app('translator')->get("site.clientName"); ?> : <span><?php echo e($order->client->name); ?></span></h5>
            <h5><?php echo app('translator')->get("site.created_at"); ?> : <span><?php echo e($order->created_at->toFormattedDateString()); ?></span></h5>
            <?php if($order->discount > 0): ?>
                <h3><?php echo app('translator')->get("site.discount"); ?> : <span><?php echo e($order->discount); ?> جنية</span></h3>
                <h3><?php echo app('translator')->get("site.totalAfterDis"); ?> :
                    <span><?php echo e(number_format($order->total_price - $order->discount , 2)); ?> جنية</span></h3>
            <?php else: ?>
                <h3><?php echo app('translator')->get("site.total"); ?> : <span><?php echo e(number_format($order->total_price , 2)); ?> جنية</span></h3>
            <?php endif; ?>

        </div>

    </div>
    <button class="btn btn-block btn-primary print-btn"><i class="fa fa-print"></i> <?php echo app('translator')->get("site.print"); ?> </button>
</div>
<script>
    $(".print-btn").on("click", function () {
        $(this).prev().print();
    })
</script>
<?php /**PATH E:\POS-New\resources\views/dashboard/orders/_products.blade.php ENDPATH**/ ?>